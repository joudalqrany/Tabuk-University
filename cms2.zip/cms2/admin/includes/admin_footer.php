<style>
           body {
            background-image: url("../images/gro3.jpg");
            background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;

}
           
           h1   {color: red;}
            p  {}
          </style>

          <style>
        .contact-container {
            display: flex;
            align-items: center;
            margin: 20px;
            font-family: Arial, sans-serif;
        }
        .contact-container img {
            width: 100px; 
            height: auto; 
            margin-right: 20px; 
        }
        .contact-details {
            line-height: 1.6; 
        }
    </style>


<div class="contact-container">
<img src="../images/tbu.png" alt="Tabuk University" width="100" height="100">    
        
        <div class="contact-details">
            <h4>Contact us:</h4>
            <p>Email: <a href="mailto:ut@ut.edu.sa">ut@ut.edu.sa</a></p>
            <p>Phone: 014 427 3022</p>
            <p>WhatsApp: 0144568000</p>
            <p>X: <a href="https://x.com/U_Tabuk" target="_blank">@U_Tabuk</a></p>
        </div>
    </div>

<h5 style="text-align:center"; >All rights reserved &copy; University of Tabuk 2024 AD - 1446 AH </h5> <!--Your Website 2014-->

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
