<style>

 /*#next {
  left: 129px;
  width: 43px;
  background: url('./images/map.jpg') -91px 0;
}*/

.well{

    background-color: #8DAE95;  
}

</style>

<div class="well">

<a href="https://maps.app.goo.gl/pFqubiRxdyDzR1ZT6?g_st=com.google.maps.preview.copy"> <img src="./images/map.jpg" alt="Tabuk University" width="300" height="200"></a>

<p>The University of Tabuk welcomes all diligent students <br> 
and we are alerted not to bring visitors at study times </p> 
  <!--  <p>Email:ut@ut.edu.sa <br>
   phone:014 427 3022 <br>
   WhatsApp: 0144568000<br>
   X: @U_Tabuk
</p> </div> -->